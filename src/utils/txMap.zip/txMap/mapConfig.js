/* eslint-disable import/no-anonymous-default-export */
export default {
    LOCATION_KEY: 'FSSBZ-DZOKG-MQ4QJ-ITEJD-TKI3H-PRB6D', // 腾讯位置服务的key
    APP_NAME: 'test', // 应用名称
    SERVER_CATEGORY: '生活服务', // 小程序服务类型
    MAP_SERVER_URL: 'https://apis.map.qq.com', // 地图服务的BASE_URL
};
